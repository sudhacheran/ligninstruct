package recursive;

class Util {
    private  monolignol mono;
    private  boolean isUpdated;
    
    
    

    public  monolignol getMono() {
        return mono;
    }

 	public  boolean isUpdated() {
		return isUpdated;
	}

	public  void setUpdated(boolean isUpdated) {
		this.isUpdated = isUpdated;
	}

	public  void setMono(monolignol mono) {
		this.mono = mono;
	}
    
    
}
